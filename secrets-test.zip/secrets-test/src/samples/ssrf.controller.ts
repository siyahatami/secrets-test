import {
  Controller,
  Get,
  Query,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import axios from 'axios';

@Controller('fetch')
export class FetchController {
  constructor(private httpService: HttpService) {}

  @Get()
  async fetchData1(@Query('url') url: string): Promise<any> {
    if (!url) {
      throw new HttpException('URL is required', HttpStatus.BAD_REQUEST);
    }

    try {
      // Insecure: Fetching data from a URL provided directly by the user
      // This can lead to SSRF attacks if the URL points to internal services or unintended external services
      const response = await firstValueFrom(this.httpService.get(url));
      return response.data;
    } catch (error) {
      throw new HttpException(
        'Failed to fetch data',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get()
  async fetchData2(@Query('url') url: string): Promise<any> {
    if (!url) {
      throw new HttpException('URL is required', HttpStatus.BAD_REQUEST);
    }

    try {
      // Insecure: Fetching data from a URL provided directly by the user
      // This can lead to SSRF attacks if the URL points to internal services or unintended external services
      const response = await axios.get(url);
      return response.data;
    } catch (error) {
      throw new HttpException(
        'Failed to fetch data',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
