import { Controller, Post, Body, UseGuards, Req } from '@nestjs/common';
import { Request } from 'express';
import { CsrfGuard } from './csrf.guard'; // Assume this is a custom guard implementing CSRF check
import { InventoryService } from './inventory.service';

@Controller('inventory')
export class InventoryController {
    constructor(private readonly inventoryService: InventoryService) {}

    @Post('update')
    async updateInventory(@Body() updateDetails: { itemId: number; quantity: number }, @Req() req: Request) {
        
         // CSRF Vulnerability: Performing state-changing operations without anti-CSRF tokens.
         // An attacker could trick a user into submitting a request to this endpoint without their consent.

        try {
            await this.inventoryService.updateItemQuantity(updateDetails.itemId, updateDetails.quantity);
            return { message: 'Inventory updated successfully' };
        } catch (error) {
            throw new Error('Failed to update inventory');
        }
    }

}