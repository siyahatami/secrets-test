Items marked as 'Expected' are expected to be detected by the SAST solution. The other vulnerabilities might be present but could be less straightforward to detect, as they may be unclear or ambiguous

The expected ones:

- sql-injection.ts: SQL Injection
- xss.service.ts: Cross-Site Scripting (XSS)
- ssrf.controller.ts: Server-Side Request Forgery (SSRF)
- csrf.controller.ts: Cross-Site Request Forgery (CSRF)
- deserialize.controller.ts: Insecure Deserialization // detected
- boxes.controller.ts / main.ts: Security Misconfiguration
- database.provider.ts: Use of Hard-coded Credentials
- file.controller.ts: File Upload Vulnerabilities
- xml.controller.ts: XML External Entities (XXE) // detected
- redirect.controller.ts: Insecure Redirects
- email.controller.ts: Misuse of Email Protocols
- logging.service.ts: Log Forging
- files.controller.ts: Unchecked External Process Execution // detected
- product.review.controller.ts: Command Injection // detected
- feedback.controller.ts: Template Injection
- api.documentation.ts: Sensitive Information in Documentation
- utility.service.ts: Using Components with Known Vulnerabilities
- profile.controller.ts: Json injection

<!--
   SAST findings: Out of 18 sample codes, 5 are detected.
   Secret Scanning findings: Out of (59) kyes, 10 are detected.
-->
