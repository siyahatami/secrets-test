import {
  Controller,
  Post,
  UseInterceptors,
  UploadedFile,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';

@Controller('files')
export class FileController {
  @Post('upload')
  @UseInterceptors(FileInterceptor('file'))
  uploadFile(@UploadedFile() file: Express.Multer.File) {
    if (!file) {
      throw new HttpException('No file provided', HttpStatus.BAD_REQUEST);
    }

    // Insecure: Storing uploaded file directly without validation or sanitization
    const fs = require('fs');
    const path = `./uploads/${file.originalname}`;

    // Writing file to the server without checking its content or type
    fs.writeFileSync(path, file.buffer);

    return {
      message: 'File uploaded successfully',
      filename: file.originalname,
    };
  }
}
