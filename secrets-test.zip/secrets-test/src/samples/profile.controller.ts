import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus,
} from '@nestjs/common';

@Controller('profile')
export class ProfileController {
  private users = [{ id: 1, name: 'John Doe', email: 'john@example.com' }];

  @Post('update')
  updateProfile(@Body() profileData: any): string {
    const user = this.users.find((u) => u.id === profileData.id);
    if (!user) {
      throw new HttpException('User not found', HttpStatus.NOT_FOUND);
    }

    // Insecure: Directly assigning properties from user-supplied JSON to an existing object.
    //  While Object.assign() doesn't allow prototype pollution (manipulating base objects like __proto__ or constructor
    //  properties that affect all instances of the inherited objects), it can still be used to overwrite existing properties
    // of the user object.
    Object.assign(user, profileData);
    return 'Profile updated successfully';
  }
}
