import {
  Column,
  createConnection,
  Entity,
  PrimaryGeneratedColumn,
  Repository,
} from 'typeorm';
import { Injectable, Inject, Controller, Get } from '@nestjs/common';

// -------------------------------------------------------------------------

export const dbProviders = [
  {
    provide: 'DATABASE_CONNECTION',
    useFactory: async () =>
      await createConnection({
        type: 'postgres',
        host: 'localhost',
        port: 5432,
        username: 'admin',
        password: 'admin123',
        database: 'myapp',
        entities: [
          // your entities here, e.g., User
        ],
        synchronize: true,
      }),
  },
];

// -------------------------------------------------------------------------

@Entity()
export class DbUser {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  email: string;
}

// -------------------------------------------------------------------------

@Injectable()
export class DbService {
  constructor(
    @Inject('DATABASE_CONNECTION')
    private connection: Repository<DbUser>,
  ) {}

  async findAll(): Promise<DbUser[]> {
    return this.connection.find();
  }
}

// -------------------------------------------------------------------------

@Controller('users')
export class DbController {
  constructor(private readonly dbService: DbService) {}

  @Get()
  async findAll(): Promise<DbUser[]> {
    return this.dbService.findAll();
  }
}
