import { Controller, Post, Body, Logger } from '@nestjs/common';

@Controller('feedback')
export class LoggingController {
  private readonly logger = new Logger(LoggingController.name);

  @Post()
  submitFeedback(@Body() feedback: { username: string; message: string }) {
    // Insecure: Logging user input directly without sanitization
    this.logger.log(
      `Feedback received from ${feedback.username}: ${feedback.message}`,
    );

    return { message: 'Feedback submitted successfully' };
  }
}
