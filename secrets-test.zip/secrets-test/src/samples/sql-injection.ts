import { Controller, Get, Query } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Cat } from './cat.entity';

@Controller('users')
export class CatsController {
  constructor(
    @InjectRepository(Cat)
    private readonly catRepository: Repository<Cat>,
  ) {}

  @Get('find')
  async findUser(@Query('catname') catname: string): Promise<Cat[]> {
    // Insecure SQL query: directly concatenating user input into the query string.
    // This could lead to SQL Injection if the 'catname' parameter is not properly sanitized.
    const query = `SELECT * FROM user WHERE catname = '${catname}'`;

    // Executing the raw SQL query using TypeORM's `query` method
    return await this.catRepository.query(query);
  }
}
