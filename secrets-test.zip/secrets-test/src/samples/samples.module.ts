import { Module } from '@nestjs/common';

import { ApiController } from './api.documentation';
import { BoxesController } from './boxes.controller';
import { CsrfController } from './csrf.controller';
import { DbController, DbService, dbProviders } from './database.provider';
import { DeserializeController } from './deserialize.controller';
import { EmailController } from './email.controller';
import { FeedbackController } from './feedback.controller';
import { FileController } from './file.controller';
import { FilesController } from './files.controller';
import { InventoryController } from './inventory.controller';
import { LoggingController } from './logging.service';
import { ProductReviewController } from './product.review.controller';
import { ProfileController } from './profile.controller';
import { RedirectController } from './redirect.controller';
import { CatsController } from './sql-injection';
import { FetchController } from './ssrf.controller';
import { UtilityService } from './utility.service';
import { XmlController } from './xml.controller';
import { MessagesController } from './xss.service';

@Module({
  controllers: [
    ApiController,
    BoxesController,
    CsrfController,
    DbController,
    DeserializeController,
    EmailController,
    FeedbackController,
    FileController,
    FilesController,
    InventoryController,
    LoggingController,
    ProductReviewController,
    ProfileController,
    RedirectController,
    CatsController,
    FetchController,
    UtilityService,
    XmlController,
    MessagesController,
  ],
  providers: [...dbProviders, DbService],
})
export class SamplesModule {}
