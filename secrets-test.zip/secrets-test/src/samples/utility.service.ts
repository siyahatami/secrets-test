import { Injectable } from '@nestjs/common';
import * as lodash from 'lodash';

@Injectable()
export class UtilityService {
  // Using a vulnerable method from lodash that can cause prototype pollution
  public extendUser(input: any): any {
    // The `extend` function in lodash can be misused to modify the prototype of an object.
    // If untrusted input is passed to this function, it could lead to prototype pollution.
    return lodash.extend({}, input);
  }
}
