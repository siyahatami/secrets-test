import { Controller, Post, Body } from '@nestjs/common';
import { exec } from 'child_process';

@Controller('product/reviews')
export class ProductReviewController {
    @Post('create')
    createReview(@Body() reviewDetails: { productId: string; reviewText: string }) {
        // Injection Flaws: Vulnerable to command injection if user input is used to construct shell commands.
        const command = `echo ${reviewDetails.reviewText} >> reviews.txt`; // Unsafe command construction
        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(`exec error: ${error}`);
                return;
            }
            console.log(`Review added to product ${reviewDetails.productId}`);
        });
        // User input should never be directly included in command strings. Always validate and sanitize input.
    }
}
