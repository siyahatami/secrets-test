import {
  Controller,
  Post,
  Req,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { Request } from 'express';
import * as libxmljs from 'libxmljs';

@Controller('xml')
export class XmlController {
  @Post('parse')
  async parseXml(@Req() request: Request): Promise<any> {
    try {
      const xmlData = await this.getXmlData(request);

      // Parse the XML data which might include malicious external entities
      const xmlDoc = libxmljs.parseXml(xmlData, { noent: true });

      return xmlDoc.toString();
    } catch (error) {
      throw new HttpException('Failed to parse XML', HttpStatus.BAD_REQUEST);
    }
  }

  private async getXmlData(request: Request): Promise<string> {
    // Simulate getting XML data from a request body
    return request.body;
  }
}

/*

  Example XXE Payload:
    <?xml version="1.0"?>
    <!DOCTYPE root [
      <!ELEMENT root ANY >
      <!ENTITY ext SYSTEM "file:///etc/passwd" >
    ]>
    <root>&ext;</root>

*/
