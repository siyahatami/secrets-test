import {
  Controller,
  Get,
  Query,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { exec } from 'child_process';

@Controller('files')
export class FilesController {
  @Get('list')
  listFiles(@Query('dir') dir: string) {
    return this.execute_func(dir);
  }

  private execute_func(dir: string) {
    return new Promise((resolve, reject) => {
      // Insecure: Executing a shell command that includes user input without validation
      exec(`ls -l ${dir}`, (error, stdout, stderr) => {
        if (error) {
          reject(
            new HttpException(
              `Error listing files: ${stderr}`,
              HttpStatus.INTERNAL_SERVER_ERROR,
            ),
          );
          return;
        }
        resolve(stdout);
      });
    });
  }
}
