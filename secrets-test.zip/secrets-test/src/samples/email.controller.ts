import {
  Controller,
  Post,
  Body,
  UseGuards,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import * as nodemailer from 'nodemailer';

@Controller('email')
export class EmailController {
  private transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'your-email@gmail.com',
        pass: 'your-password',
      },
    });
  }

  @Post('send')
  async sendEmail(
    @Body()
    emailDetails: {
      from: string;
      to: string;
      subject: string;
      body: string;
    },
  ) {
    // Misuse of Email Protocols: Allowing email sending functionality to be exploited for spam or phishing attacks
    // by not validating the sender or the recipient, body, or by allowing users to send emails without proper rate limiting.

    try {
      let info = await this.transporter.sendMail({
        from: emailDetails.from,
        to: emailDetails.to,
        subject: emailDetails.subject,
        text: emailDetails.body,
        // html: "<b>Hello world?</b>", // HTML body content, if needed
      });

      console.log('Message sent: %s', info.messageId);
      return { message: 'Email sent successfully', messageId: info.messageId };
    } catch (error) {
      console.error('Failed to send email:', error);
      throw new HttpException(
        'Failed to send email',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
