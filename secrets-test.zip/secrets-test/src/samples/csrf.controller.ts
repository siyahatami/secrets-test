import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus,
} from '@nestjs/common';

@Controller('profile')
export class CsrfController {
  @Post('update')
  updateProfile(@Body() profileData: any): string {
    // Insecure: Updating user profile without any CSRF protection
    // An attacker could forge a request from another site to change user profile details if the user is authenticated
    console.log(`Profile updated with: ${JSON.stringify(profileData)}`);
    return 'Profile updated successfully';
  }
}
