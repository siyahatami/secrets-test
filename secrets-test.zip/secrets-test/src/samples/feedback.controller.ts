import { Get, Injectable } from '@nestjs/common';
import * as Handlebars from 'handlebars';

@Injectable()
export class FeedbackController {
  @Get()
  async renderFeedbackTemplate(
    userName: string,
    feedbackText: string,
  ): Promise<string> {
    // Unsafe template rendering with user input leading to potential template injection.
    const rawTemplate = `Hello {{userName}}, thanks for your feedback: "{{feedbackText}}"`;

    // This direct substitution without sanitization or validation poses a risk of template injection.
    const template = Handlebars.compile(rawTemplate);
    const result = template({ userName, feedbackText });

    // Handlebars doesn't run escaping automatically. It should be done manually as follows:
    // const safeUserName = Handlebars.Utils.escapeExpression(userName);

    return result;
  }
}
