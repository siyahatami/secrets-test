import { Controller, Get, Injectable, Query, Res } from '@nestjs/common';
import { Response } from 'express';

@Controller('messages')
export class MessagesController {
  @Get('process')
  processOrder(orderDetails: string) {
    // Improper sanitization of user input in order processing
    // This example directly uses 'orderDetails' in a context where it could be rendered in a webpage,
    // potentially leading to XSS if 'orderDetails' include malicious scripts
    const processedOrder = `Order Details: ${orderDetails}`;
    return processedOrder;
  }

  @Get('display')
  displayMessage(@Query('message') message: string, @Res() res: Response) {
    // Insecure: Directly rendering user input into HTML without sanitization
    // This could lead to Cross-Site Scripting (XSS) if the 'message' contains JavaScript code.
    res.send(`<html><body><h1>Message: ${message}</h1></body></html>`);
  }
}
