import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus,
} from '@nestjs/common';

@Controller('users')
export class DeserializeController {
  @Post('update')
  updateUserProfile(@Body() userData: any) {
    try {
      // Insecure Deserialization: Deserializing user data directly without validation
      // Directly converting JSON string to JavaScript object can lead to issues if the content includes
      // malicious data designed to exploit serialization flaws.
      const user = eval(`(${userData})`);
      // update user profile
      return 'Profile updated successfully with: ' + JSON.stringify(user);
    } catch (error) {
      throw new HttpException(
        'Failed to update profile',
        HttpStatus.BAD_REQUEST,
      );
    }
  }
}
