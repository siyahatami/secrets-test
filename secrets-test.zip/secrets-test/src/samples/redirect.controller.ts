import { Controller, Get, Query, Res } from '@nestjs/common';
import { Response } from 'express';

@Controller('order')
export class RedirectController {
  @Get('redirect')
  redirectUser(@Query('url') url: string, @Res() res: Response) {
    // Insecure Redirects: Redirecting users to attacker-controlled sites based on user input.
    // Without validation, an attacker could supply a malicious URL leading to phishing sites or other harmful content.
    return res.redirect(url); // Unsafe: No validation on the 'url' parameter.
  }
}
