import {
  Controller,
  Get,
  Param,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { BoxService } from './box.service';

@Controller('users')
export class BoxesController {
  private readonly logger = new Logger(BoxesController.name);

  constructor(private readonly boxService: BoxService) {}

  @Get(':id')
  async getBox(@Param('id') id: string): Promise<any> {
    try {
      const box = await this.boxService.findById(id);
      if (!box) {
        throw new HttpException('Box not found', HttpStatus.NOT_FOUND);
      }
      return box;
    } catch (error) {
      // Log the detailed error internally and provide a generic error message to the client
      this.logger.error(
        `Internal error occurred while fetching box: ${error.message}`,
      );
      throw new HttpException(
        'Internal server error',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
