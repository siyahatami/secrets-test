import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import helmet from 'helmet';
import * as cookieParser from 'cookie-parser';
import * as csurf from 'csurf';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Insecure configuration: Misconfigured Helmet
  app.use(
    helmet({
      contentSecurityPolicy: false, // Security misconfiguration: Disabling CSP can expose to cross-site scripting (XSS) attacks
      frameguard: false, // Security misconfiguration: Not preventing clickjacking attacks
    }),
  );

  // app.use(cookieParser());
  app.use(csurf({ cookie: true })); // requires existance of '_csrf' param in the request body or 'CSRF-Token' param in the request headers. It can be injected to the forms by:      @Post() root(@Req() req: Request) { const token = req.csrfToken(); }

  await app.listen(3000);
}
bootstrap();
