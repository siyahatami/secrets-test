import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  private secretToken = 'ghp_xHJkL12345YzI1b2c3d4e5f6g7h8';
  private oauthToken = 'ya29.a0AfH6SMB12345xyzAbCdEfGhIjKlMnOpQrStUv';

  getHello(): string {
    return 'Hello World! ' + this.secretToken;
  }
}
