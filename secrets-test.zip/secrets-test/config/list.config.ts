// The commented ones should be regenrated with valid token structures.

export default {
  Username: 'admin',
  Password: 'p@ssW0rd!',
  URI_Passwords: 'ftp://user:p@ssw0rd@host/',
  DB_USER: 'user1',
  JDBC: 'jdbc:mysql://localhost:3306/mydb?user=myUser&password=myPass',
  ODBC: 'Driver={SQL Server};Server=myServerAddress;Database=myDataBase;Uid=myUsername;Pwd=myPassword;',
  ADO: 'Provider=SQLNCLI11;Server=myServerAddress;Database=myDataBase;Uid=myUsername;Pwd=myPassword;',
  Dot_NET:
    'Server=myServerAddress;Database=myDataBase;User Id=myUsername;Password=myPassword;',
  PostgreSQLCon: 'host=localhost dbname=mydb user=myuser password=mypass',
  mongodbUri: 'mongodb://admin:password123@localhost:27017/myapp',
  JWT1: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c',
  Slack_API_token: 'xoxb-123456789012-1234567890123-abcdefgHijkLmnopQRstuvWxyz',
  EKS_OIDC_Access_Tokens:
    'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwMTIzNDU2Nzg5MDEiLCJhdWQiOiJleGFtcGxlLWF1ZGllbmNlIiwiZXhwIjoxNjE1MTI3OTk5LCJpYXQiOjE2MTUxMjQzOTksImlzcyI6Imh0dHBzOi8vZXhhbXBsZS5jb20vIiwibmFtZSI6IkVYQU1QTEUgVVNFUiIsImVtYWlsIjoiZXhhbXBsZUBleGFtcGxlLmNvbSIsImV4YW1wbGVfY3VzdG9tX2NsYWltIjoiZXhhbXBsZV92YWx1ZSJ9.WdYaSfCpOy8G2X4cF6K9E6lKsGRS3Uf7j6qJcZnnnTm7OaA6WxgX2H9pTQB7aBnrvkHcgUeUnPn7D6EwHn6jNA',
  Fastly_API_Key: 'ABCD1234EFGH5678IJKL9012MNOP3456QRST7890UVWX', // updated
  DataDog_API_Key: '3e7428aade334baf82e673b8a092e97a',
  LaunchDarkly_SDK_Key: 'sdk-8f3f2a36-3e1f-4a18-a9c1-1234567890ab',
  Slack_API_Token: 'xoxp-1234567890-1234567890-1234567890-abcd1234',
  // Slack_App_Token: 'xoxb-123456789012-098765432109-ABCDEFGH1234IJKLM5678',     // updated
  AlienVault_API_Key: '3a2b1c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9g0h',
  Apollo_API_Key:
    'service:my-apollo-service-2374:ghp_19c9bFV6M7Y15hV5Zp7J3zQ22bG3xO3r4A',
  // Terraform_API_Token: 'abcd1234.efgh5678.ijkl9012.mnop3456',    // updated
  // CircleCI_API_Token: '1234567890abcdef1234567890abcdef12345678',   // updated
  ClickUp_API_Token: 'pk_3182376_Q233NZDZ8AVULEGGCHLKG2HFXWD6MJLC',
  Amazon_MWS_Auth_Token: 'amzn.mws.12345678-1234-1234-1234-1234567890ab',
  Stripe_Secret_Key: 'sk_test_4eC39HqLyjWDarjtT1zdp7dc',
  Jenkins_API_Token: '11b02f3ac0a4de4845c81c273e6d3a88',
  DockerRegistryToken: 'dXNlcjpwYXNzd29yZA==',
  Kubernetes_API_Token:
    'eyJhbGciOiJSUzI1NiIsImtpZCI6IkpXVCJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJkZWZhdWx0Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZWNyZXQubmFtZSI6Im15LXNlcnZpY2UtYWNjb3VudC10b2tlbi1ocm5qYiIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJteS1zZXJ2aWNlLWFjY291bnQiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC51aWQiOiIxMjM0NTY3OC05YWJjLWRlZmEtYmNkZS1lZmdoaWprbG1ub3AiLCJzdWIiOiJzeXN0ZW06c2VydmljZWFjY291bnQ6ZGVmYXVsdDpteS1zZXJ2aWNlLWFjY291bnQifQ.WDJa3IRlQ3O9kX5wTSzvGgW1CUH5E6inR4nZ5q6s5HkQyFzOcWbXvQlIzWt1H8lT1s8P3z4jB3K2Z9NcQnK5oF2JsY0bXui8v1eHrSv9OgjxR2Xv7J3EoCwZmEj3XbEeZBKxHXXV7JLkXSnm1AnxvSgHKKtY5iyW3ShTSzKLVIUDO8HzmXy2TOCIFHaQZdH0OJ3Q3KHWVbjLYH2Qv9lZIvb8OXGZKgH3YUfpyyLHWL4Th7T0GDRgkQe9xMVvGuhAPsNROFmdZb1MMVnMjE3N2pX5AiySsVQ8TlSp0zgC0LDxKbTqLniEBS9QfKORygoIlNRgQTSBT0PvWZgBSzKQx2Q',
  // GIT_Refresh_Tokens: 'ghr_abcdefghijklmnopqrstuvwxyz0123456789ABCDEF',    // updated
  // GIT_Personal_Access_Tokens: 'ghp_abcdefghijklmnopqrstuvwxyz0123456789ABCDEF',    // updated
  // GIT_OAuth_Access_Tokens: 'gho_abcdefghijklmnopqrstuvwxyz0123456789ABCDEF',    // updated
  // GIT_App_Tokens: 'ghu_abcdefghijklmnopqrstuvwxyz0123456789ABCDEF',        // updated
  // AWS_Access_Key_ID: 'AKIAIOSFODNN7EXAMPLE',   // ?
  // AWS_Access_Key: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',    // ?
  Presigned_URL:
    'https://examplebucket.s3.amazonaws.com/test.txt?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIOSFODNN7EXAMPLE%2F20230204%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20230204T000000Z&X-Amz-Expires=86400&X-Amz-Signature=1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef&X-Amz-SignedHeaders=host',
  OAuth_Client_ID: '1234567890abcdef1234',
  Client_Secret: 'abcdef1234567890abcdef1234567890',
  ECDSA_private_key: `-----BEGIN EC PRIVATE KEY-----
  MHcCAQEEIOzpfVh+3T+X6a4IVjPl3tvaHpIjyH2uyl3G/T4WU6pLoAoGCCqGSM49
  AwEHoUQDQgAEWzRQgI4UgZlkaJ3BCcPdIAnVOT0tYSpkXjPw0mHy5VR0oSoHcZRr
  y8hYS1chD58P9+hLvE7IWesdYtLuH3yjXQ==
  -----END EC PRIVATE KEY-----
  `,
  Azure_Subscription_ID: '45b60d85-fdfe-4cb3-8027-564d60c35f03',
  Azure_Tenant_ID: '8aefb023-2b34-4da1-9baa-8bc8c9d6a490',
  Azure_Client_ID: 'c2547eb4-d5fa-4e8a-807a-7e3a9a1c9b77',
  Azure_Client_Secret: 'f~E3dG5s8D~mT9Q~W_QJ2z~5HnZsIjCupL',
  AzureAccessKey_legacy:
    'Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==',
  AzureAccessKey: 'B3t6iD8pTr+G1qY6eWx9hO3cJk7l8pNq7uTbW2xZ4mQ=',
  Azure_Storage_Account_Key_legacy:
    'Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==',
  Azure_Storage_Account_Key: 'sv6oIq+T/E1s2r4u9P8gXmQ1hF3bU0dV+f6j8s2y4kN=',
  Azure_SAS_Token:
    'sv=2019-12-12&ss=b&srt=sco&sp=rwdlacx&se=2022-12-01T00:00:00Z&st=2021-12-01T00:00:00Z&spr=https&sig=%2F%2F%2F%2F%3D',
  Azure_App_Service_Publish_Profile_Passwords:
    '<userPWD>YourStrongP@ssword</userPWD>',
  GCP_Project_ID: 'my-gcp-project-id',
  GCP_Private_Key_ID: 'b3319a147514cd8aaa8bbea5eae8d3415e2ea6a1',
  GCP_Client_Email:
    'my-service-account@my-gcp-project-id.iam.gserviceaccount.com',
  GCP_Private_Key: `-----BEGIN PRIVATE KEY-----
  MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCs9Zq5DVq9Jk+y
  YLdP8NHGnrM2gZ2MhW6R9YdPdG6kVG7q+7lE4H8WwR8ZlSAY3DfMwIq3XZr8L2FJ
  2cCQBwCcM+oFJp9zT8hP/TbZuKsHJNzL0o2D3s8dTiY1N0JdV0xw6U5y5JYXm67L
  9u5x5v8Ah4nHZxMdO0b+Z5B2H4J/qy8DdKtCnFJL5U+9sPIH/C5HTdgMz5H2PoLX
  /5UJ+JTh1MsF4es0HnJ/Cj8XVzMBD4HX8p4kx7FZh+mY/zF5E3+HwY5B6C3F8sfP
  L1RmC7q1AgMBAAECggEAAhR9MXp6RQQ71bLq3uhWkGWU/2C+u2m9CqXeMx4Ry0Al
  5akY3Fd6P+QFt+aRwmC1PUPfC1Lk2BRzU6LeXQZtiYOD5S4HunPT4xL9YvJQTCxF
  TwIDAQAB
  -----END PRIVATE KEY-----
  `,
  GCP_Service_Account: {
    type: 'service_account',
    project_id: 'project-id',
    private_key_id: 'key-id',
    client_email: 'service-account-email',
    client_id: 'client-id',
    auth_uri: 'https://accounts.google.com/o/oauth2/auth',
    token_uri: 'https://oauth2.googleapis.com/token',
    auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
    client_x509_cert_url:
      'https://www.googleapis.com/robot/v1/metadata/x509/service-account-email',
  },
  RSA_PublicKey: `ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQD3D6y/CgXwK3H8V+PD+gWQ4sF7gQa7kDBMRMbyTBq8xxGJ9iOmZKzE1n0H5Bz5PcF3sIjessSUHW76lyZawG0SbXSebW9ldO+nVXnK2YsXU8LrOHYkEFPF5pUghfGeqJcR+GKQh3XrSfJGx5G1Op1pDbaJeKq8FKxWLL0C9k/RW5kyL2k5kt2R0Yiw6gNnMK5C9Rz3JxnW9fetP0YzZXZzgrtHdrYNXHq2BvsLpI9YVspIgQTVK5xAFbriyTvSV0H8XR7yF5B9PheNWc9zXGA1TJk+jJKSMF0YSD2BcvQ== user@example.com`,
  RSA_PrivateKey: `
    -----BEGIN RSA PRIVATE KEY-----
  MIIEpAIBAAKCAQEA7Z5N6mDixGzVjxH4kTQTPzi5Y0N8zvG2L7oJDkZHC5upGOrA
  fV1WYR/3K1T1YrFSpH5dq2GQzSH6D5EWG5aB5qG0JpOypZB4UeQ2+qRbC4L5UqDz
  T3YJqBcVFStQZnR+X4iO8B1SIZ8uF0/WniMzueFpSzTJdLZj5P5WpFq1BdYQ7w5k
  NNNk3RyIv+jqepGCRZ9V6WPjbL4x/3zZAsCJn+8H5nI6dH3hJ6EAWGKy9afTbEzI
  jC+fxFb6H8JmmCZd5cK1X0Wg8B5jBlAA8BMR+L+aLJWp2HJ4K0q5DePzQ0Z9SaHr
  7nFz3B7MwyTBt5sCAwEAAQKCAQEA5B2XDPGDFk5Rav4VKB9EVHt5amFpCJ1UpAaI
  7n+ldB+RB2SCiJLRB6weR3qCtJaD+VyIgP1O4ARa3+CBIhjChPvHyhT9G3Oz9kET
  L8BKkKX2L8Y0pPMojk8L7mom/qwNHZ1HndYfDkUoj6DBpO0PHJHLnDxU5G8Op4QX
  tPVvgBc4FpJ9QiI2MqMEdkEVVib1t3BVsQD02aPLwP0E3R9PXLGjR9yZB8x/0RYy
  6CN1nCR62GAQu3oqPcZ6d9KFCRzgVJTxkDvnMqPiUorf6vqz5OJwDq6XsUlFJW3Y
  2Uu9PszXzFDTL5s7PbfR5xTBu1M0J8DZbwKb6QKCAQEA9tMpE/TBf1YWh7JsH0qS
  oOARYV8mShtLJmZJ3t3BbX+3rHSzE1D8vG9KAVVHQw1X4oCNescF1BZ8IbEeErTJ
  25dwVCgqPEB1DjyD42jxM+Mlv8lKJ/3G2hL2hJ2Gi6qwbPMBPpRjxJqxkrbhJz8a
  wvB9enoHz/A6sGj7QIcDvJsMCqCmz+F0ELJmEdYcP5Cp5CjyH5QZaNaViHPMzK2D
  oYUJRVA9bvpCnEgDqXtEiH4D4G7t6jviYk2e2bR+5MM5fRmRFlRaFgaowm6JSh3x
  6K7pjfhe8CmHy5qD5JPaAgMBAAECggEAOJmWpCJbN6aldD+ZP0IcC3F/U+GjZ4+E
  8k/MGKm5LJH7P0LV9xjS7LlzvB5j7k9mDBoUqlq3Jk8UoRJRCyyZ5jMFb9nmmCNH
  U+2x/2sPd5aBx6H0SkJFHKrslW4DfHKLygfHb+MIVJMKzE3ElxSuvdMoE6HsFWR3
  HPQK1L5bTiC/1Vx5pds0WvB5aapxHc4q9C4e7e8CQJKUFWu8Bv38+a1HD1gNsStT
  H9Ply5RqO70E9GZc2x0QQCmMf+QkIOvEjw8dG4O5Q0y2M5b+D/ZPzidjX8oDmFyT
  s9xRbV/3h+1ZQp5CWQKCAQEA8H0yzMn1xO9c5ZwRO/Fjs8yGmPUNzXO9P5IldOy1
  8E+SVNNoxUJsl+DRD+PfK+GiBvO9tDZHTB8kHR8+2HUjUzFGSb4ZOcHTgM+pCuyj
  zT4LcIh1RWxPiMbxNQ==
  -----END RSA PRIVATE KEY-----
    `,
  SSL_public_key: `-----BEGIN CERTIFICATE-----
  MIIDdTCCAl2gAwIBAgIJANUE5068vBqIMA0GCSqGSIb3DQEBCwUAMCoxFzAVBgNV
  BAMMDnd3dy5leGFtcGxlLmNvbTAeFw0yMTAxMDEwMDAwMDBaFw0zMTAxMDEwMDAw
  MDBaMCoxFzAVBgNVBAMMDnd3dy5leGFtcGxlLmNvbTCCASIwDQYJKoZIhvcNAQEB
  BQADggEPADCCAQoCggEBAO3M7k6Zp4YRk9p0F1Cj14RWS/EQKbIsdLt+2ezj4Rf4
  9Z5B+DSDZq3/7HTD1JVVmJpvP8mK4ZB/Vt2SeUzDfMRHfXQpC9IHD2/qXpFJSgak
  2m3UlcqjU5Lmw2sCCLlDVStvHbJLBC9g4UsMxyK9fgH5B3EvW+Q1ppLzTFND7gmt
  Qp6dxuoWkCRSGrUivwIDAQABo1AwTjAdBgNVHQ4EFgQUm1ZkT7YJ3UJZBv0RuTCU
  a9Jv5hAwHwYDVR0jBBgwFoAUm1ZkT7YJ3UJZBv0RuTCUa9Jv5hAwDAYDVR0TBAUw
  AwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAi/M5jA4GhIbZLQWh5zJavcGhXh5kMiUK
  DUuL02AftIykV6M2TcLXCNBZsV7+HvHnDIVxPLAYqKm9aWM8SmBuDkWbU1FLTIZG
  9f6TPYzg0PFK+I0RN0FJpCygT5SJI9Wq+GovzZmj2X8OlEIR9NyXsP6DxAEiM0JQ
  Nz5CnqHy2xW3LJ3eEvEhX/7yF5P3hTf4kqHrX+T6SyPnHAU2XV/Z1jLaAl/owj1X
  zEoyWJ9kPV6LqYQsR1L9KEji6cIFTI8B1oG9aYvSNg6x9kdmYZeF6V2Hr5hw0xY5
  rUQRqZJ3NfDx+GxmHUDvKcCwC6mYDgLpYQzMTAl0eT/6JrQUnqOv4A==
  -----END CERTIFICATE-----
  `,
  GPG_Pub_Key: `
  -----BEGIN PGP PUBLIC KEY BLOCK-----

  mQINBF6M8gkBEADdVsuH2BnJ8HJZoKzW2Wb0DwR9gZiLWzOQ/GFz7A1HqE3CwG6j
  IYz3ZvLfPRyM3O1Dz5vF5/CmMUBRarpl9KyDjB3D9PYV2A1ZWBqBk5G2C5P6C6Oi
  Aq2WwQCGHxquHYc9zFwP6mK4qPtI1m0vDB0FpEd4Q5Qzpufhx+R+HMeJ4TjCABi+
  AVCkvgC3XaJiYOajPbSPqkP4t1QpHtNvQDfzSkhgc5BQht7FJgztZnFjXfLiY8QX
  Ow6D5D7O/jQn2E1L2sIc4zTGMkA1FJ8ZR7orxRV+BtQkEJ+FgSqxDFqhd5xPCqDl
  5W2z2GuHURwUJ9bYFV8O5SO6gZ0IsU6wqy/7vFkGk3y3HCjljgQb+1I+e4ZM2DOO
  8HUh/U4EO8jJGKBFCTeH5OI0Ym4VKrlna1gSQHo9arcaJXZGUnGG7VWpFBqTSSpL
  6CZ0S14DHBf7+aK19hUfX1eETvkvZC1U9V5U6Y9Bcsn+HbJbkr9JQqUJ9PZBSu3k
  D/3VJpFh6QZKpVqUvKf0p7c8a2L7VOvL/SMaNwARAQABtC1HUEcgS2V5IEV4YW1w
  bGUgPGV4YW1wbGVAZXhhbXBsZS5jb20+iQJUBBMBCAA+FiEEXYKz4qHrdOvfrz7E
  WRYhRmX7+O4FAmKj2dwCGwMFCQPCZwAFCwkIBwIGFQoJCAsCBBYCAwECHgECF4AA
  CgkQWRYhRmX7+O5JdQ/+JmJ4RjWcYW6whROf6PThMtYF/q+G6+bJzE4H6PqP0BvL
  vk8qZ6SE7Bkxf+iJqOtW2RgB0A8P2Y3kH6EDCq3S/dXJkTBa+mkMMFV8/SxauF3x
  P8R/EYR1FN9h2Ks5L5HjX9CXQtjS5I0JqX5L6mYYQmZP3N5e4H0WzqVqW3CQYQoW
  I/qxvJc5GGRv2VqMEmI5U+IoU2vqkxK5AXU7Q7x3P6EVZ1MJ9C6CDE5+OSh6zvKH
  G+wZqO/Th/hJ9JThI9IADjPx3c7fJLoyTDsL+t2YsF0q3qFIY1D0L5gyPC2V5sIh
  i5CarxFFoZt0nD+J4reFJ7vR49v0Hc7P/9V8KIGJ1uoYJ/6L+VQlL0IRF/GrA/9k
  zP8A3qgH+XJ5T+HJbR5sS0Cg5znPDiB1KdYJk1SOiMGrdCn9N2M5Lnbq8YFbwwLJ
  N0avHRim//j9C2E0J+HKDjaHyXXwKqTJ8KlhC+Gm67Sm9yGZrhA7wC+7o6TkD2tf
  BqMAry3KkPAgNi6I9uO5Ag0EXozyCQEQAKdPAmxGZIqQkPGoCf2wC2T0WU0+9bYm
  hDlkgpLjaxuKn0UO1N0/M8R1GQ7fahvCnQsJICHFx9G2YH4D/q+I2bl5RPx2F0s8
  C/9IHeF/hXGs9cJvO8K2bhZTPC3hEhISEn+G0qIxvPjMJ+KVoPB2Lb7Cv5S+QKbI
  f0p4JxJwSTCZV4bhV0Z0Yf7B28Hf8YvI8LzSj+4DTBGUVOkC/RM9I8HbCZBzZp/C
  2qB9N/c8qRHjJNiIpCvMXRl3vn2KZjEY03TiZNJ9RPBA8L7ZGi9f8JWPaXD2UZ6t
  c9PcFqfCfWZ1YIW+bbqBQY9s1IC6uSnOVRJZk0C8Lr+JhMEMEQEAAYkCNgQYAQgA
  IbYhBBF2Cs+Kh63Tr368+xFkWIUZl+/juwUCXozyCQIbDAUJA8JnAAAKCRBYFiFG
  Zfv47knkD/9Y/V3e9QsJdOrq2XJ+H5lB0Hsj7Y8CodSzhmp/hZuen9C2ZnpU5HJr
  R8KJZ0fnP7uK0XnI1uRjZsmTJcZ5G2q+C9M6Hv9jW4KQn+/tDk9C8FkZ4I3Z5P5L
  gbTc6L7QjKjTIq3k3RbIpJNonGIEzRFvV8l2/5JQ5FH9JG8H2FJpYHs8nPb3C3S3
  KJ3XKm3RcYqmRvKatCZ0F+hhZ9PhR0WjV4sF/2G9k2G9L2/ppkZtB+oGkGsHPspP
  L/7uK2u4F3W5RjbFjI+3c9Pj8kzP1JL5C1Fj6G7Y3PnDpFSCA5k0qJgk3BzKk5Ct
  C/3W8hJPPB3RZz4hL5svB/0D/R8=
  =dK5J
  -----END PGP PUBLIC KEY BLOCK-----
  `,
  GPG_Private_Key: `
  -----BEGIN PGP PRIVATE KEY BLOCK-----

  lQPGBF6M8gkBEADdVsuH2BnJ8HJZoKzW2Wb0DwR9gZiLWzOQ/GFz7A1HqE3CwG6j
  IYz3ZvLfPRyM3O1Dz5vF5/CmMUBRarpl9KyDjB3D9PYV2A1ZWBqBk5G2C5P6C6Oi
  Aq2WwQCGHxquHYc9zFwP6mK4qPtI1m0vDB0FpEd4Q5Qzpufhx+R+HMeJ4TjCABi+
  AVCkvgC3XaJiYOajPbSPqkP4t1QpHtNvQDfzSkhgc5BQht7FJgztZnFjXfLiY8QX
  Ow6D5D7O/jQn2E1L2sIc4zTGMkA1FJ8ZR7orxRV+BtQkEJ+FgSqxDFqhd5xPCqDl
  5W2z2GuHURwUJ9bYFV8O5SO6gZ0IsU6wqy/7vFkGk3y3HCjljgQb+1I+e4ZM2DOO
  8HUh/U4EO8jJGKBFCTeH5OI0Ym4VKrlna1gSQHo9arcaJXZGUnGG7VWpFBqTSSpL
  6CZ0S14DHBf7+aK19hUfX1eETvkvZC1U9V5U6Y9Bcsn+HbJbkr9JQqUJ9PZBSu3k
  D/3VJpFh6QZKpVqUvKf0p7c8a2L7VOvL/SMaNwARAQAB/gkDCP+Q8HHIg5m6WYK5
  f/2O1IkF+gE5fX95Km5V7F3yZ8HJZoKzW2Wb0DwR9gZiLWzOQ/GFz7A1HqE3CwG6
  jIYz3ZvLfPRyM3O1Dz5vF5/CmMUBRarpl9KyDjB3D9PYV2A1ZWBqBk5G2C5P6C6O
  iAq2WwQCGHxquHYc9zFwP6mK4qPtI1m0vDB0FpEd4Q5Qzpufhx+R+HMeJ4TjCABi
  +AVCkvgC3XaJiYOajPbSPqkP4t1QpHtNvQDfzSkhgc5BQht7FJgztZnFjXfLiY8Q
  XOw6D5D7O/jQn2E1L2sIc4zTGMkA1FJ8ZR7orxRV+BtQkEJ+FgSqxDFqhd5xPCqD
  l5W2z2GuHURwUJ9bYFV8O5SO6gZ0IsU6wqy/7vFkGk3y3HCjljgQb+1I+e4ZM2DO
  O8HUh/U4EO8jJGKBFCTeH5OI0Ym4VKrlna1gSQHo9arcaJXZGUnGG7VWpFBqTSSp
  L6CZ0S14DHBf7+aK19hUfX1eETvkvZC1U9V5U6Y9Bcsn+HbJbkr9JQqUJ9PZBSu3
  kD/3VJpFh6QZKpVqUvKf0p7c8a2L7VOvL/SMa
  =XRQ3
  -----END PGP PRIVATE KEY BLOCK-----
  `,
};

/*
  There are also follwing keys in other files:
    app.service.ts:         secretToken, oauthToken
    samples/database.provider.ts:     username, password
    samples/api.documenation.ts:    username, password
    terraform/main.tf:    access_key, secret_key, username, password
  
  Secret Scanning findings: Out of (59) kyes, 10 are detected.
  
  */
